;(function($) {
	
	$.addEventListener('DOMContentLoaded', function() {
		
		var canvas = Raphael(0, 0, 300, 300);
			
		canvas.image('html5.png', 0, 0, 300, 300);
		circle = canvas.circle(100, 100, 100);
		
	}, false);

}(document));