### How to install

1. Compress `threejs.sublime-completions` into `threejs.sublime-package`.

```shell
zip threejs.sublime-package threejs.sublime-completions
```

2. Copy the compressed file into `Sublime Text 2/Pristine Packages`.
