#!/bin/sh

python sublime.py --include common --include extras --output editors/sublimetext2/threejs.sublime-completions
