;(function($) {
	
	$.addEventListener('DOMContentLoaded', function() {
		
		var canvas = Raphael(0, 0, 300, 300),
			rect = canvas.rect(0, 0, 100, 100);
			
			rect.attr('fill', '#F00');
		
	}, false);

}(document));